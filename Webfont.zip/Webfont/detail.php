<?php include 'template/header.php' ?>

<section class=" container-fluid">
    <div class="  detail">

        <div class="row">

            <div class="col-7 index-right ">

                <div class="d-flex flex-column bd-highlight mb-3 detail-left ">
                    <div class="p-9 bd-highlight div-item-up detail-left-item">
                        <div class=" blog-top-link">
                            <div class=" detail-link-top dowload-link ">
                                <a href="">Home</a>
                                <i class="fa-solid fa-chevron-right"></i>
                                <a href=" " class=" a-blog " act>Serif</a>

                            </div>
                        </div>
                        <!------------ Lọc mobile  -------------------->
                        <div class="col-lg-3 item-sidebar mb-4 mb-lg-0">
                            <div class="filter-mobile">
                                <div class="nav-filter">
                                    <input type="checkbox" id="menu-bar-loc" class="head-body-input">
                                    <label for="menu-bar-loc" class="">
                                        <button class="btn btn-secondary btn-show-filter ">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" viewBox="0 0 16 18" fill="none">
                                                <path d="M5 2.00001C4.73478 2.00001 4.48043 2.10537 4.29289 2.2929C4.10536 2.48044 4 2.73479 4 3.00001C4 3.26523 4.10536 3.51958 4.29289 3.70712C4.48043 3.89465 4.73478 4.00001 5 4.00001C5.26522 4.00001 5.51957 3.89465 5.70711 3.70712C5.89464 3.51958 6 3.26523 6 3.00001C6 2.73479 5.89464 2.48044 5.70711 2.2929C5.51957 2.10537 5.26522 2.00001 5 2.00001ZM2.17 2.00001C2.3766 1.41448 2.75974 0.907443 3.2666 0.548799C3.77346 0.190154 4.37909 -0.00244141 5 -0.00244141C5.62091 -0.00244141 6.22654 0.190154 6.7334 0.548799C7.24026 0.907443 7.6234 1.41448 7.83 2.00001H15C15.2652 2.00001 15.5196 2.10537 15.7071 2.2929C15.8946 2.48044 16 2.73479 16 3.00001C16 3.26523 15.8946 3.51958 15.7071 3.70712C15.5196 3.89465 15.2652 4.00001 15 4.00001H7.83C7.6234 4.58554 7.24026 5.09258 6.7334 5.45122C6.22654 5.80986 5.62091 6.00246 5 6.00246C4.37909 6.00246 3.77346 5.80986 3.2666 5.45122C2.75974 5.09258 2.3766 4.58554 2.17 4.00001H1C0.734784 4.00001 0.48043 3.89465 0.292893 3.70712C0.105357 3.51958 0 3.26523 0 3.00001C0 2.73479 0.105357 2.48044 0.292893 2.2929C0.48043 2.10537 0.734784 2.00001 1 2.00001H2.17ZM11 8.00001C10.7348 8.00001 10.4804 8.10537 10.2929 8.2929C10.1054 8.48044 10 8.73479 10 9.00001C10 9.26523 10.1054 9.51958 10.2929 9.70712C10.4804 9.89465 10.7348 10 11 10C11.2652 10 11.5196 9.89465 11.7071 9.70712C11.8946 9.51958 12 9.26523 12 9.00001C12 8.73479 11.8946 8.48044 11.7071 8.2929C11.5196 8.10537 11.2652 8.00001 11 8.00001ZM8.17 8.00001C8.3766 7.41448 8.75974 6.90744 9.2666 6.5488C9.77346 6.19015 10.3791 5.99756 11 5.99756C11.6209 5.99756 12.2265 6.19015 12.7334 6.5488C13.2403 6.90744 13.6234 7.41448 13.83 8.00001H15C15.2652 8.00001 15.5196 8.10537 15.7071 8.2929C15.8946 8.48044 16 8.73479 16 9.00001C16 9.26523 15.8946 9.51958 15.7071 9.70712C15.5196 9.89465 15.2652 10 15 10H13.83C13.6234 10.5855 13.2403 11.0926 12.7334 11.4512C12.2265 11.8099 11.6209 12.0025 11 12.0025C10.3791 12.0025 9.77346 11.8099 9.2666 11.4512C8.75974 11.0926 8.3766 10.5855 8.17 10H1C0.734784 10 0.48043 9.89465 0.292893 9.70712C0.105357 9.51958 0 9.26523 0 9.00001C0 8.73479 0.105357 8.48044 0.292893 8.2929C0.48043 8.10537 0.734784 8.00001 1 8.00001H8.17ZM5 14C4.73478 14 4.48043 14.1054 4.29289 14.2929C4.10536 14.4804 4 14.7348 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8947 4.73478 16 5 16C5.26522 16 5.51957 15.8947 5.70711 15.7071C5.89464 15.5196 6 15.2652 6 15C6 14.7348 5.89464 14.4804 5.70711 14.2929C5.51957 14.1054 5.26522 14 5 14ZM2.17 14C2.3766 13.4145 2.75974 12.9074 3.2666 12.5488C3.77346 12.1902 4.37909 11.9976 5 11.9976C5.62091 11.9976 6.22654 12.1902 6.7334 12.5488C7.24026 12.9074 7.6234 13.4145 7.83 14H15C15.2652 14 15.5196 14.1054 15.7071 14.2929C15.8946 14.4804 16 14.7348 16 15C16 15.2652 15.8946 15.5196 15.7071 15.7071C15.5196 15.8947 15.2652 16 15 16H7.83C7.6234 16.5855 7.24026 17.0926 6.7334 17.4512C6.22654 17.8099 5.62091 18.0025 5 18.0025C4.37909 18.0025 3.77346 17.8099 3.2666 17.4512C2.75974 17.0926 2.3766 16.5855 2.17 16H1C0.734784 16 0.48043 15.8947 0.292893 15.7071C0.105357 15.5196 0 15.2652 0 15C0 14.7348 0.105357 14.4804 0.292893 14.2929C0.48043 14.1054 0.734784 14 1 14H2.17Z" fill="#454545" />
                                            </svg>
                                            <span> Bộ lọc</span>
                                        </button>
                                    </label>
                                </div>
                                <a type="button" class="btn btn-secondary btn-filter ">
                                    <i class="fa-solid fa-xmark"></i>
                                    <span>Xóa bộ lọc</span>
                                </a>
                            </div>
                        </div>
                        <!-- ----------------------------------------- -->
                        <div class=" detail-left-item-top    ">
                            <div class="d-flex justify-content-center">
                                <div class="d-flex flex-column mb-3 ">
                                    <h2>Bunlay Font - Free download</h2>
                                    <div class=" detail-top-content"><img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" /></div>
                                    <div class="detail-top-img">
                                        <div class=" text-center">
                                            <div class="row">
                                                <div class="col">
                                                    <a href="" type="button" data-bs-toggle="modal" data-bs-target="#detail"><img src="./assets/app/images/content/detail.png" alt="" class="index-img" /></a>
                                                </div>
                                                <div class="col">
                                                    <a href="" type="button" data-bs-toggle="modal" data-bs-target="#detail"><img src="./assets/app/images/content/detail.png" alt="" class="index-img" /></a>

                                                </div>
                                                <div class="col">
                                                    <a href="" type="button" data-bs-toggle="modal" data-bs-target="#detail"><img src="./assets/app/images/content/detail.png" alt="" class="index-img" /></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=" detail-mid-content">
                                        <span>Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! Masterfully designed to become a true favorite, this font has the potential to bring each of your creative ideas to the highest level! This font is PUA encoded which means you can access all of the glyphs and swashes with ease!</span>
                                    </div>
                                    <div class=" detail-mid-link">
                                        <div class="row detail-mid-link-a">
                                            <div class="col-8">
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                            </div>
                                            <div class="col-4 detail-mid-link-btn">
                                                <button>Report download link error</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="p-2 detail-mid-test">
                                        <div class="row ">
                                            <div class="col-5 detail-mid-test-input">
                                                <input type="text" placeholder="Your text here...">

                                            </div>
                                            <div class="col-3 detail-mid-test-span">
                                                <span class="detail-mid-test-span-1">AA</span>
                                                <span>Aa</span>
                                                <span>aa</span>
                                            </div>
                                            <div class="col-4 detail-mid-test-range ">
                                                <input type="range" min="0" max="5" id="customRange1">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="">

                        <div class="d-flex flex-column mb-3 detail-bot-Stanfe">

                            <div class="d-flex flex-column mb-3 detail-bot-item detail-bot-item-1">
                                <div class=" detail-bot-item-top">
                                    <div class="row">
                                        <div class="col-4 detail-bot-item-content">
                                            <span>Stanfe-Medium-otf</span>
                                        </div>
                                        <div class="col detail-bot-item-mid">
                                            <div class="d-flex justify-content-end">
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">View glyphs (216)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-bot-item-bot-a" href="">Otf
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                                        <path d="M0.666749 10.1666C0.666338 9.43023 0.853696 8.70593 1.21112 8.06213C1.56854 7.41833 2.08421 6.8763 2.70942 6.48726C2.87442 5.20065 3.50261 4.01826 4.47643 3.16136C5.45024 2.30446 6.70294 1.83179 8.00008 1.83179C9.29723 1.83179 10.5499 2.30446 11.5237 3.16136C12.4976 4.01826 13.1257 5.20065 13.2907 6.48726C14.0662 6.96972 14.6695 7.68486 15.0143 8.53058C15.3591 9.3763 15.4279 10.3093 15.2108 11.1965C14.9938 12.0836 14.502 12.8795 13.8056 13.4705C13.1093 14.0615 12.244 14.4173 11.3334 14.4873L4.66675 14.4999C2.42942 14.3173 0.666749 12.4479 0.666749 10.1666ZM11.2321 13.1579C11.8626 13.1094 12.4617 12.8629 12.9438 12.4536C13.4259 12.0443 13.7663 11.4931 13.9164 10.8788C14.0665 10.2644 14.0186 9.61834 13.7796 9.03285C13.5405 8.44735 13.1226 7.95236 12.5854 7.61859L12.0474 7.28326L11.9674 6.65526C11.8428 5.69105 11.3713 4.80522 10.6411 4.16332C9.91093 3.52142 8.97198 3.16738 7.99975 3.16738C7.02752 3.16738 6.08856 3.52142 5.35836 4.16332C4.62816 4.80522 4.1567 5.69105 4.03208 6.65526L3.95208 7.28326L3.41542 7.61859C2.87828 7.95232 2.46034 8.44725 2.22128 9.03269C1.98222 9.61813 1.93427 10.2641 2.08429 10.8785C2.2343 11.4928 2.5746 12.044 3.05658 12.4534C3.53857 12.8627 4.13758 13.1093 4.76808 13.1579L4.88341 13.1666H11.1167L11.2321 13.1579ZM8.66675 8.49992H10.6667L8.00008 11.8333L5.33342 8.49992H7.33342V5.83326H8.66675V8.49992Z" fill="#454545" />
                                                    </svg>
                                                </a>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <div class=" detail-bot-item-h h1">
                                    <h4>The quick brown fox jumps over the lazy dog</h4>
                                </div>
                            </div>
                            <div class="d-flex flex-column mb-3 detail-bot-item">
                                <div class=" detail-bot-item-top">
                                    <div class="row">
                                        <div class="col-4 detail-bot-item-content">
                                            <span>Stanfe-Bold-otf</span>
                                        </div>
                                        <div class="col detail-bot-item-mid">
                                            <div class="d-flex justify-content-end">
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">View glyphs (216)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-bot-item-bot-a" href="">Otf
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                                        <path d="M0.666749 10.1666C0.666338 9.43023 0.853696 8.70593 1.21112 8.06213C1.56854 7.41833 2.08421 6.8763 2.70942 6.48726C2.87442 5.20065 3.50261 4.01826 4.47643 3.16136C5.45024 2.30446 6.70294 1.83179 8.00008 1.83179C9.29723 1.83179 10.5499 2.30446 11.5237 3.16136C12.4976 4.01826 13.1257 5.20065 13.2907 6.48726C14.0662 6.96972 14.6695 7.68486 15.0143 8.53058C15.3591 9.3763 15.4279 10.3093 15.2108 11.1965C14.9938 12.0836 14.502 12.8795 13.8056 13.4705C13.1093 14.0615 12.244 14.4173 11.3334 14.4873L4.66675 14.4999C2.42942 14.3173 0.666749 12.4479 0.666749 10.1666ZM11.2321 13.1579C11.8626 13.1094 12.4617 12.8629 12.9438 12.4536C13.4259 12.0443 13.7663 11.4931 13.9164 10.8788C14.0665 10.2644 14.0186 9.61834 13.7796 9.03285C13.5405 8.44735 13.1226 7.95236 12.5854 7.61859L12.0474 7.28326L11.9674 6.65526C11.8428 5.69105 11.3713 4.80522 10.6411 4.16332C9.91093 3.52142 8.97198 3.16738 7.99975 3.16738C7.02752 3.16738 6.08856 3.52142 5.35836 4.16332C4.62816 4.80522 4.1567 5.69105 4.03208 6.65526L3.95208 7.28326L3.41542 7.61859C2.87828 7.95232 2.46034 8.44725 2.22128 9.03269C1.98222 9.61813 1.93427 10.2641 2.08429 10.8785C2.2343 11.4928 2.5746 12.044 3.05658 12.4534C3.53857 12.8627 4.13758 13.1093 4.76808 13.1579L4.88341 13.1666H11.1167L11.2321 13.1579ZM8.66675 8.49992H10.6667L8.00008 11.8333L5.33342 8.49992H7.33342V5.83326H8.66675V8.49992Z" fill="#454545" />
                                                    </svg>
                                                </a>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <div class=" detail-bot-item-h h2">
                                    <h4>The quick brown fox jumps over the lazy dog</h4>
                                </div>
                            </div>
                            <div class="d-flex flex-column mb-3 detail-bot-item">
                                <div class=" detail-bot-item-top">
                                    <div class="row">
                                        <div class="col-4 detail-bot-item-content">
                                            <span>Stanfe-ExtralBold-otf</span>
                                        </div>
                                        <div class="col detail-bot-item-mid">
                                            <div class="d-flex justify-content-end">
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">View glyphs (216)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-bot-item-bot-a" href="">Otf
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                                        <path d="M0.666749 10.1666C0.666338 9.43023 0.853696 8.70593 1.21112 8.06213C1.56854 7.41833 2.08421 6.8763 2.70942 6.48726C2.87442 5.20065 3.50261 4.01826 4.47643 3.16136C5.45024 2.30446 6.70294 1.83179 8.00008 1.83179C9.29723 1.83179 10.5499 2.30446 11.5237 3.16136C12.4976 4.01826 13.1257 5.20065 13.2907 6.48726C14.0662 6.96972 14.6695 7.68486 15.0143 8.53058C15.3591 9.3763 15.4279 10.3093 15.2108 11.1965C14.9938 12.0836 14.502 12.8795 13.8056 13.4705C13.1093 14.0615 12.244 14.4173 11.3334 14.4873L4.66675 14.4999C2.42942 14.3173 0.666749 12.4479 0.666749 10.1666ZM11.2321 13.1579C11.8626 13.1094 12.4617 12.8629 12.9438 12.4536C13.4259 12.0443 13.7663 11.4931 13.9164 10.8788C14.0665 10.2644 14.0186 9.61834 13.7796 9.03285C13.5405 8.44735 13.1226 7.95236 12.5854 7.61859L12.0474 7.28326L11.9674 6.65526C11.8428 5.69105 11.3713 4.80522 10.6411 4.16332C9.91093 3.52142 8.97198 3.16738 7.99975 3.16738C7.02752 3.16738 6.08856 3.52142 5.35836 4.16332C4.62816 4.80522 4.1567 5.69105 4.03208 6.65526L3.95208 7.28326L3.41542 7.61859C2.87828 7.95232 2.46034 8.44725 2.22128 9.03269C1.98222 9.61813 1.93427 10.2641 2.08429 10.8785C2.2343 11.4928 2.5746 12.044 3.05658 12.4534C3.53857 12.8627 4.13758 13.1093 4.76808 13.1579L4.88341 13.1666H11.1167L11.2321 13.1579ZM8.66675 8.49992H10.6667L8.00008 11.8333L5.33342 8.49992H7.33342V5.83326H8.66675V8.49992Z" fill="#454545" />
                                                    </svg>
                                                </a>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <div class=" detail-bot-item-h h3">
                                    <h4>The quick brown fox jumps over the lazy dog</h4>
                                </div>
                            </div>
                            <div class="d-flex flex-column mb-3 detail-bot-item">
                                <div class=" detail-bot-item-top">
                                    <div class="row">
                                        <div class="col-4 detail-bot-item-content">
                                            <span>Stanfe-Black-otf</span>
                                        </div>
                                        <div class="col detail-bot-item-mid">
                                            <div class="d-flex justify-content-end">
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">View glyphs (216)</a>
                                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-bot-item-bot-a" href="">Otf
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                                        <path d="M0.666749 10.1666C0.666338 9.43023 0.853696 8.70593 1.21112 8.06213C1.56854 7.41833 2.08421 6.8763 2.70942 6.48726C2.87442 5.20065 3.50261 4.01826 4.47643 3.16136C5.45024 2.30446 6.70294 1.83179 8.00008 1.83179C9.29723 1.83179 10.5499 2.30446 11.5237 3.16136C12.4976 4.01826 13.1257 5.20065 13.2907 6.48726C14.0662 6.96972 14.6695 7.68486 15.0143 8.53058C15.3591 9.3763 15.4279 10.3093 15.2108 11.1965C14.9938 12.0836 14.502 12.8795 13.8056 13.4705C13.1093 14.0615 12.244 14.4173 11.3334 14.4873L4.66675 14.4999C2.42942 14.3173 0.666749 12.4479 0.666749 10.1666ZM11.2321 13.1579C11.8626 13.1094 12.4617 12.8629 12.9438 12.4536C13.4259 12.0443 13.7663 11.4931 13.9164 10.8788C14.0665 10.2644 14.0186 9.61834 13.7796 9.03285C13.5405 8.44735 13.1226 7.95236 12.5854 7.61859L12.0474 7.28326L11.9674 6.65526C11.8428 5.69105 11.3713 4.80522 10.6411 4.16332C9.91093 3.52142 8.97198 3.16738 7.99975 3.16738C7.02752 3.16738 6.08856 3.52142 5.35836 4.16332C4.62816 4.80522 4.1567 5.69105 4.03208 6.65526L3.95208 7.28326L3.41542 7.61859C2.87828 7.95232 2.46034 8.44725 2.22128 9.03269C1.98222 9.61813 1.93427 10.2641 2.08429 10.8785C2.2343 11.4928 2.5746 12.044 3.05658 12.4534C3.53857 12.8627 4.13758 13.1093 4.76808 13.1579L4.88341 13.1666H11.1167L11.2321 13.1579ZM8.66675 8.49992H10.6667L8.00008 11.8333L5.33342 8.49992H7.33342V5.83326H8.66675V8.49992Z" fill="#454545" />
                                                    </svg>
                                                </a>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <div class=" detail-bot-item-h h4">
                                    <h4>The quick brown fox jumps over the lazy dog</h4>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

                <div class=" detail-left-bot">
                    <h2>Random font</h2>
                    <div class="detail-left-bot-detail">
                        <div class="row detail-left-bot-detail">
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/1.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/2.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/3.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/4.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3 col-sm-12 detail-left-bot-item">
                                <div class="detail-left-bot-item-top">
                                    <a href="./detai.php" class="">
                                        <img src="./assets/app/images/content/5.png" alt="" class="index-img" />
                                    </a>
                                    <div class="detail-left-bot-item-bot">
                                        <h4 class="text-left ">Bunlay Font - Free download</h4>
                                        <span>License: Demo, Free, Free for Personal Use</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-4 index-left " id="index-left">
                <div class="d-flex flex-column mb-3 index-item-left detail-item-left detail-right">
                    <div class="detail-right-top">

                        <div class="d-flex justify-content-between">
                            <div class="d-flex justify-content-start detail-right-top-about">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M11 7H13V9H11V7ZM11 11H13V17H11V11ZM12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20Z" fill="#454545" />
                                </svg>
                                <h5>Albout</h5>
                            </div>
                            <div class="d-flex justify-content-end filters-div-close">
                                <button class=" sidebar-close">
                                <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>
                        <div class=" detail-right-bot-about ">
                            <div class="d-flex flex-column mb-3 ">
                                <div class="p-2">
                                    <span>Designer: Ahweproject</span>
                                </div>
                                <div class="p-2">
                                    <span>Full version & Commercial license:</span>
                                    <a href="">Click now</a>
                                </div>
                                <div class="p-2">
                                    <span>Paypal account for donation:</span>
                                    <a href="">Click now</a>
                                </div>
                                <div class="p-2">
                                    <span>Email:</span>
                                    <a href="">info@noahtype.com</a>
                                </div>
                                <div class="p-2">
                                    <span>Web:</span>
                                    <a href="">noahtype.com</a>
                                </div>
                                <div class="p-2">
                                    <span>Visit:</span>
                                    <span>1200</span>
                                </div>
                                <div class="p-2">
                                    <button>DOWNLOAD</button>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="p-2">

                        <div class="d-flex justify-content-start">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M12 6L16 12L21 8L19 18H5L3 8L8 12L12 6Z" stroke="#454545" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <h5>License</h5>
                        </div>
                        <div class="p-2 detail-lef-item-License  detail-right-lice">
                            <div class="d-flex flex-wrap license-div">
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-right-lice-top" href="">Not free for commercial use</a>
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Demo</a>
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn detail-right-lice-bot" href="">Free for Personal Use</a>


                            </div>
                        </div>

                    </div>
                    <div class="p-2">
                        <div class="d-flex flex-column mb-3">
                            <div class="d-flex justify-content-start">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <g clip-path="url(#clip0_802_32)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.586 2.75696C15.9611 2.38202 16.4697 2.17139 17 2.17139C17.5303 2.17139 18.0389 2.38202 18.414 2.75696L21.243 5.58596C21.6179 5.96101 21.8286 6.46963 21.8286 6.99996C21.8286 7.53029 21.6179 8.0389 21.243 8.41396L18.414 11.243C18.0389 11.6179 17.5303 11.8285 17 11.8285C16.4697 11.8285 15.9611 11.6179 15.586 11.243L12.757 8.41396C12.3821 8.0389 12.1714 7.53029 12.1714 6.99996C12.1714 6.46963 12.3821 5.96101 12.757 5.58596L15.586 2.75696ZM17 4.17196L14.172 6.99996L17 9.82796L19.828 6.99996L17 4.17196ZM9 2.99996C9.53043 2.99996 10.0391 3.21067 10.4142 3.58575C10.7893 3.96082 11 4.46953 11 4.99996V8.99996C11 9.53039 10.7893 10.0391 10.4142 10.4142C10.0391 10.7892 9.53043 11 9 11H5C4.46957 11 3.96086 10.7892 3.58579 10.4142C3.21071 10.0391 3 9.53039 3 8.99996V4.99996C3 4.46953 3.21071 3.96082 3.58579 3.58575C3.96086 3.21067 4.46957 2.99996 5 2.99996H9ZM9 4.99996H5V8.99996H9V4.99996ZM21 15C21 14.4695 20.7893 13.9608 20.4142 13.5857C20.0391 13.2107 19.5304 13 19 13H15C14.4696 13 13.9609 13.2107 13.5858 13.5857C13.2107 13.9608 13 14.4695 13 15V19C13 19.5304 13.2107 20.0391 13.5858 20.4142C13.9609 20.7892 14.4696 21 15 21H19C19.5304 21 20.0391 20.7892 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V15ZM19 15V19H15V15H19ZM9 13C9.53043 13 10.0391 13.2107 10.4142 13.5857C10.7893 13.9608 11 14.4695 11 15V19C11 19.5304 10.7893 20.0391 10.4142 20.4142C10.0391 20.7892 9.53043 21 9 21H5C4.46957 21 3.96086 20.7892 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15C3 14.4695 3.21071 13.9608 3.58579 13.5857C3.96086 13.2107 4.46957 13 5 13H9ZM9 15H5V19H9V15Z" fill="#454545" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_802_32">
                                            <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                                <h5>Browse Font</h5>
                            </div>
                            <div class="p-2">
                                <div class="d-flex flex-wrap browse-div">
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <!-- MODAL  -->
    <div class="modal fade" id="detail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content detail-modal">
                <div class="btn-model">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                            <path d="M16 2C8.2 2 2 8.2 2 16C2 23.8 8.2 30 16 30C23.8 30 30 23.8 30 16C30 8.2 23.8 2 16 2ZM21.4 23L16 17.6L10.6 23L9 21.4L14.4 16L9 10.6L10.6 9L16 14.4L21.4 9L23 10.6L17.6 16L23 21.4L21.4 23Z" fill="#454545" />
                        </svg>
                    </button>
                </div>
                <div class="modal-body text-center ">
                    <img src="./assets/app/images/content/image5.png" alt="">
                </div>
            </div>
        </div>
    </div>





</section>

<?php include 'template/footer.php' ?>