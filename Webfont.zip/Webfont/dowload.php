<?php include 'template/header.php' ?>
<section class="container-fluid">
    <div class="dowload  ">
        <div class="p-2 blog-top-link">
            <div class=" dowload-link">
                <a href="">Home</a>
                <i class="fa-solid fa-chevron-right"></i>
                <a href=" " class=" a-blog " act>Dowload</a>

            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class=" dowload-top">
                    <div class="row">
                        <div class="col-6  dowload-top-left ">
                            <div class="d-flex flex-column mb-3 ">
                                <div class="p-2">
                                    <h4>Bunlay Font - Free download</h4>
                                </div>
                                <div class="p-2"><img src=" ./assets/app/images/content/Frame 34.png" alt=""></div>

                            </div>
                        </div>
                        <div class="col-6 dowload-top-right ">
                            <div class="d-flex flex-column mb-3">
                                <div class="p-2">
                                    <h4>Thank ! Load fonts in <span>
                                            10
                                        </span> seconds</h4>
                                </div>
                                <div class="p-2">
                                    <button><span class="span-dowload">DOWNLOAD</span></button>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

        <div class=" col dowload-bot">
            <div class=" detail-left-bot">
                <h2>Random font</h2>
                <div class="detail-left-bot-detail">
                    <div class="row  detail-left-bot-detail">
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/1.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/2.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/3.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/4.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/5.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/6.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/7.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/8.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/9.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/10.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/11.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/12.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/13.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3  col-sm-6 dowload-bot-item">
                            <div class="dowload-bot-item-top">
                                <a href="./detai.php" class="">
                                    <img src="./assets/app/images/content/14.png" alt="" class="index-img" />
                                </a>
                                <div class="dowload-bot-item-bot">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                       
                        
                    </div>
                    
                </div>

            </div>


        </div>



</section>

<?php include 'template/footer.php' ?>