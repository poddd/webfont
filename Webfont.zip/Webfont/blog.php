<?php include 'template/header.php' ?>

<section class=" container-fluid">
    <div class="blog">
        <div class="row blog-detail">
            <div class="col blog-topp">
                <div class="d-flex flex-column bd-highlight mb-3">
                    <div class="p-9 bd-highlight blog-top blog-top-left">
                        <div class="">
                            <div class="p-2 blog-top-link">
                                <div class="">
                                    <a href="">Home</a>

                                    <i class="fa-solid fa-chevron-right"></i>

                                    <a href=" " class=" a-blog " act>Bog</a>
                                </div>
                            </div>
                            <div class="p-2">
                                <div class="col ">
                                    <h3>Blog</h3>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>
                                    <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                        <!-- <div class="p-2"> -->
                                        <div class="row blog-bot-link-item">
                                            <div class="col-sm-4">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                            </div>
                                            <div class="col-sm-8 row blog-bot-link-detail">
                                                <div class="d-flex flex-column mb-3">
                                                    <div class=" blog-p2">
                                                        <h4>Instructions for installing fonts</h4>
                                                        <div class="d-flex blog-bot-link-detail-author">
                                                            <div class=" blog-p2 flex-fill">Admin</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                            <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                                <a href="">Instruct</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                    <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- </div> -->

                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-2 bd-highlight">
                        <div class="  text-center display-flex">
                            <div class="collection-navigation pt-4 ">
                                <div class=" pt-3">
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination mb-0 justify-content-center -">
                                            <li class="page-item " aria-current="page">
                                                <a class="page-link" href="#">1</a>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item">
                                                <a class="page-link" href="#">3</a>
                                            </li>

                                            <li class="page-item">
                                                <a class="page-link" href="#" aria-label="Next">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                        <g clip-path="url(#clip0_802_450)">
                                                            <path d="M2 9H17M17 9L10.25 2.25M17 9L10.25 15.75" stroke="#454545" stroke-width="2" />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_802_450">
                                                                <rect width="18" height="18" fill="white" transform="translate(0.5)" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                </a>
                                            </li>

                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-5  blog-right">
                <h3>Font Random</h3>
                <!-- <div class="container text-left"> -->
                    <div class="row container row-cols-md-2 .col-md-3  text-left   blog-right-item-detail">
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/1.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/2.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/3.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/4.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/5.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/6.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                            <div class="blog-right-item">
                                <a href="./detail.php" class="">
                                    <img src="./assets/app/images/content/7.png" alt="" class="index-img" />
                                </a>
                                <div class="">
                                    <h4 class="text-left ">Bunlay Font - Free download</h4>
                                    <span>License: Demo, Free, Free for Personal Use</span>
                                </div>
                            </div>
                        </div>
                    </div>

                <!-- </div> -->
            </div>
        </div>
    </div>
    </div>








</section>

<?php include 'template/footer.php' ?>