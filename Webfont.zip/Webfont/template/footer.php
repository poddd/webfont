<hr>

<div class="pt 2">
    <div class="footer-bottom">
        <div class="d-flex align-items-center gap-3 gap-md-4 flex-1 w-full justify-content-center ">
            <div class="overflow-auto d-flex align-items-center gap-3 gap-md-4 justify-content-start  py-4">
                <a href="" class=" text-body ">Link 1</a>
                <a href="" class=" text-body ">Link 2</a>
                <a href="" class=" text-body ">Link 3</a>
                <a href="" class="text-body ">Link 4</a>
                <a href="" class="text-body ">Link 5</a>
                <a href="" class="text-body ">Link 6</a>
            </div>
        </div>
        <div class="container">
            <div class=" text-center py-2">
                © 2024 FontloveZ.com. All rights reserved
            </div>
        </div>
    </div>
</div>

<div class="theme-overlay"></div>

<script src="./assets/vendors/jquery-3.7.1.min.js"></script>
<script src="./assets/vendors/bootstrap-5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="./assets/vendors/slick-1.8.1/slick.min.js"></script>
<script src="./assets/vendors/fancybox/fancybox.umd.js"></script>
<script src="./assets/vendors/chart.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script src="./assets/app/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $(".less-btn").click(function(){
    $(".browse-content").slideToggle();
  });
});
</script>
<script>
    $(function() {
        showFilter();

    })

    function showFilter() {
        $(".btn-show-filter").on("click", function() {

            $('.index-left').toggleClass('show');
        })
        $(".sidebar-close").on("click", function() {
            console.log('2');
            $('.index-left').removeClass('show');
        })
    }
</script>
<script>
    $(function() {
        showMenu();

    })

    function showMenu() {
        $(".btn-show-menu").on("click", function() {

            $('.nav-mobile').toggleClass('menu-show');
        })
        $(".menu-close").on("click", function() {

            $('.nav-mobile').removeClass('menu-show');
        })
    }
</script>


</body>

</html>