<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Font</title>

    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="icon" href="./assets/app/images/favicon.png" type="image/x-icon" />

    <link rel="icon" href="./assets/app/images/favicon.png" type="image/x-icon" />

    <link rel="stylesheet" href="./assets/vendors/bootstrap-5.3.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="./assets/vendors/slick-1.8.1/slick.css" />
    <link rel="stylesheet" href="./assets/vendors/fancybox/fancybox.css" />
    <link rel="stylesheet" href="./assets/app/css/style.css" />

</head>

<body>
    <header class="head-body">
        <div class="bd-highlight head-top">
            <div class="d-flex align-items-center gap-3 gap-md-4 flex-1 w-full justify-content-left">
                <div class="header-link-top">
                    <div class="container-fluid">
                        <div class="overflow-auto d-flex align-items-center gap-3 gap-md-4 justify-content-start  py-2 ">
                            <a href="" class=" text-header ">Link 1</a>
                            <a href="" class=" text-header ">Link 2</a>
                            <a href="" class=" text-header ">Link 3</a>
                            <a href="" class="text-header ">Link 4</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="d-flex flex-column bd-highlight header">
                <div class=" head-bot ">
                    <div class="row text-start im1">
                        <div class="col site-logo ">
                            <a href="./index.php" class="header-link-top-logo"><img src="../assets/app/images/logo/Frame 100.jpg" class=" " alt=""></a>
                        </div>

                        <input type="checkbox" id="menu-bar" class="head-body-input">
                        <label for="menu-bar" class="head-body-label">
                            <i class="fa-solid fa-bars"></i>
                        </label>
                        <div class="col site-logo site-ul ">
                            <ul class="nav justify-content-center header-link-bot">
                                <li class="nav-item nav-list-head">
                                    <a href="#" class="nav-link true header-link-bot-logo" aria-current="page" href="#">BROWSE FORNS</a>
                                    <ul class="">
                                        <div class="row row-cols-2">
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font có chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font có chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font không chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font không chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font chữ ký</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font chữ ký</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font có chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font không chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font không chân</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font chữ ký</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Font chữ ký</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                            <div class="col">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                                        <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                                    </svg>
                                                    <a href="#" class="nav-link nav-brow">Serif</a>
                                                </li>
                                            </div>
                                        </div>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="./topvisit.php" class="nav-link true header-link-bot-logo" aria-disabled="true">TOP VISIT</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link true header-link-bot-logo" aria-disabled="true">FORNT RANDOM</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link true header-link-bot-logo" aria-disabled="true">FORN REQUEST</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link true header-link-bot-logo" aria-disabled="true">DONATE</a>
                                </li>
                                <li class="nav-item ">

                                    <a type="button" class="nav-link true header-link-bot-logo  " data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                            <path d="M16.031 14.617L20.314 18.899L18.899 20.314L14.617 16.031C13.0237 17.3082 11.042 18.0029 9 18C4.032 18 0 13.968 0 9C0 4.032 4.032 0 9 0C13.968 0 18 4.032 18 9C18.0029 11.042 17.3082 13.0237 16.031 14.617ZM14.025 13.875C15.2941 12.5699 16.0029 10.8204 16 9C16 5.133 12.867 2 9 2C5.133 2 2 5.133 2 9C2 12.867 5.133 16 9 16C10.8204 16.0029 12.5699 15.2941 13.875 14.025L14.025 13.875Z" fill="#454545" />
                                        </svg>
                                    </a>
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- -----------------------------------------HEAD MENU---------  -->
    <div class="head-mobile">
        <div class="bd-highlight head-top">
            <div class="d-flex align-items-center gap-3 gap-md-4 flex-1 w-full justify-content-left">
                <div class="header-link-top">
                    <div class="container-fluid">
                        <div class="overflow-auto d-flex align-items-center gap-3 gap-md-4 justify-content-start  py-2 ">
                            <a href="" class=" text-header ">Link 1</a>
                            <a href="" class=" text-header ">Link 2</a>
                            <a href="" class=" text-header ">Link 3</a>
                            <a href="" class="text-header ">Link 4</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="d-flex justify-content-between moblie-menu">
                <div class="d-flex justify-content-start  ">
                    <div class=" site-logo ">
                        <a href="./index.php" class="header-link-top-logo"><img src="../assets/app/images/logo/Frame 100.jpg" class=" " alt=""></a>
                    </div>
                </div>
                <div class="d-flex justify-content-end">
                    <!-- <input type="checkbox" id="menu-bar-mobile" class="head-body-input">
                    <label for="menu-bar-mobile" class="head-body-label">
                        <i class="fa-solid fa-bars"></i>
                    </label> -->
                    <button class=" btn-show-menu ">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <nav class="nav-mobile" id="nav-mobile">
                        <ul>

                            <div class="d-flex justify-content-between top-menunav-mobile ">
                                <div class="d-flex justify-content-start  ">
                                    <div class=" site-logo ">
                                        <a href="./index.php" class="header-link-top-logo"><img src="../assets/app/images/logo/Frame 100.jpg" class=" " alt=""></a>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <button class=" menu-close ">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </div>

                            <li>
                                <button class="less-btn">BROWSE FORNS</button>
                                <ul class="browse-content">
                                    <li>
                                        <div class="detail-head-menu-item">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="20" viewBox="0 0 14 15" fill="none">
                                                <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                            </svg>
                                            <a href="#" class="nav-link nav-brow">Font có chân</a>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=" detail-head-menu-item">
                                            <svg class="" xmlns="http://www.w3.org/2000/svg" width="50" height="20" viewBox="0 0 14 15" fill="none">
                                                <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                            </svg>
                                            <a href="#" class="nav-link nav-brow">Font có chân</a>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="detail-head-menu-item">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="20" viewBox="0 0 14 15" fill="none">
                                                <path d="M4.62 1.2002L3.92 1.9502L7.62 5.7002L3.92 9.4502L4.62 10.2002L9.12 5.7002L4.62 1.2002Z" fill="#454545" />
                                            </svg>
                                            <a href="#" class="nav-link nav-brow">Font có chân</a>
                                        </div>
                                    </li>

                                </ul>
                            </li>
                            <li><a href="">TOP VISIT</a></li>
                            <li><a href="">FORNT RANDOM</a></li>
                            <li><a href="">FORN REQUEST</a></li>
                            <li><a href="">DONATE</a></li>

                            <li class=" ">
                                <a type="button" class="nav-link true header-link-bot-logo menu-close " data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                        <path d="M16.031 14.617L20.314 18.899L18.899 20.314L14.617 16.031C13.0237 17.3082 11.042 18.0029 9 18C4.032 18 0 13.968 0 9C0 4.032 4.032 0 9 0C13.968 0 18 4.032 18 9C18.0029 11.042 17.3082 13.0237 16.031 14.617ZM14.025 13.875C15.2941 12.5699 16.0029 10.8204 16 9C16 5.133 12.867 2 9 2C5.133 2 2 5.133 2 9C2 12.867 5.133 16 9 16C10.8204 16.0029 12.5699 15.2941 13.875 14.025L14.025 13.875Z" fill="#454545" />
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
        </div>

    </div>

    <!-- ----------------------------------------MODAL SEARCH---------------------------------------------------------------- -->
    <div class="modal fade  search-head" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content search-head-div ">
                <div class="modal-body  search-head-content  ">
                    <form class="form-head" action="">
                        <div class="input-group form-head-input">
                            <input type="text" class="form-control" placeholder="Find fonts here" aria-describedby="button-addon2">
                            <button>
                                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none">
                                    <path d="M18.031 16.617L22.314 20.899L20.899 22.314L16.617 18.031C15.0237 19.3082 13.042 20.0029 11 20C6.032 20 2 15.968 2 11C2 6.032 6.032 2 11 2C15.968 2 20 6.032 20 11C20.0029 13.042 19.3082 15.0237 18.031 16.617ZM16.025 15.875C17.2941 14.5699 18.0029 12.8204 18 11C18 7.133 14.867 4 11 4C7.133 4 4 7.133 4 11C4 14.867 7.133 18 11 18C12.8204 18.0029 14.5699 17.2941 15.875 16.025L16.025 15.875Z" fill="white" />
                                </svg>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>