<?php include 'template/header.php' ?>

<section class="container-fluid">
    <div class="index">
        <div class="row">
            <div class="col-9 index-right">

                <div class="d-flex flex-column bd-highlight mb-3">
                    <div class="p-9 bd-highlight div-item-up">
                        <form class="d-flex justify-content-start form-index" action="action_page.php ">
                            <input class="search-index" type="text" placeholder="Search.." name="search">
                            <button class="nav-link true" type="submit" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <path d="M18.031 17.117L22.314 21.399L20.899 22.814L16.617 18.531C15.0237 19.8082 13.042 20.5029 11 20.5C6.032 20.5 2 16.468 2 11.5C2 6.532 6.032 2.5 11 2.5C15.968 2.5 20 6.532 20 11.5C20.0029 13.542 19.3082 15.5237 18.031 17.117ZM16.025 16.375C17.2941 15.0699 18.0029 13.3204 18 11.5C18 7.633 14.867 4.5 11 4.5C7.133 4.5 4 7.633 4 11.5C4 15.367 7.133 18.5 11 18.5C12.8204 18.5029 14.5699 17.7941 15.875 16.525L16.025 16.375Z" fill="#454545" />
                                </svg>
                            </button>
                        </form>
                        <div class="   index-col-item  ">
                            <h2>12345 Free font</h2>
                            <!------------ Lọc mobile  -------------------->
                            <div class="col-lg-3 item-sidebar mb-4 mb-lg-0">
                                <div class="filter-mobile">
                                    <div class="nav-filter">
                                        <input type="checkbox" id="menu-bar-loc" class="head-body-input">
                                        <label for="menu-bar-loc" class="">
                                            <button class="btn btn-secondary btn-show-filter ">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" viewBox="0 0 16 18" fill="none">
                                                    <path d="M5 2.00001C4.73478 2.00001 4.48043 2.10537 4.29289 2.2929C4.10536 2.48044 4 2.73479 4 3.00001C4 3.26523 4.10536 3.51958 4.29289 3.70712C4.48043 3.89465 4.73478 4.00001 5 4.00001C5.26522 4.00001 5.51957 3.89465 5.70711 3.70712C5.89464 3.51958 6 3.26523 6 3.00001C6 2.73479 5.89464 2.48044 5.70711 2.2929C5.51957 2.10537 5.26522 2.00001 5 2.00001ZM2.17 2.00001C2.3766 1.41448 2.75974 0.907443 3.2666 0.548799C3.77346 0.190154 4.37909 -0.00244141 5 -0.00244141C5.62091 -0.00244141 6.22654 0.190154 6.7334 0.548799C7.24026 0.907443 7.6234 1.41448 7.83 2.00001H15C15.2652 2.00001 15.5196 2.10537 15.7071 2.2929C15.8946 2.48044 16 2.73479 16 3.00001C16 3.26523 15.8946 3.51958 15.7071 3.70712C15.5196 3.89465 15.2652 4.00001 15 4.00001H7.83C7.6234 4.58554 7.24026 5.09258 6.7334 5.45122C6.22654 5.80986 5.62091 6.00246 5 6.00246C4.37909 6.00246 3.77346 5.80986 3.2666 5.45122C2.75974 5.09258 2.3766 4.58554 2.17 4.00001H1C0.734784 4.00001 0.48043 3.89465 0.292893 3.70712C0.105357 3.51958 0 3.26523 0 3.00001C0 2.73479 0.105357 2.48044 0.292893 2.2929C0.48043 2.10537 0.734784 2.00001 1 2.00001H2.17ZM11 8.00001C10.7348 8.00001 10.4804 8.10537 10.2929 8.2929C10.1054 8.48044 10 8.73479 10 9.00001C10 9.26523 10.1054 9.51958 10.2929 9.70712C10.4804 9.89465 10.7348 10 11 10C11.2652 10 11.5196 9.89465 11.7071 9.70712C11.8946 9.51958 12 9.26523 12 9.00001C12 8.73479 11.8946 8.48044 11.7071 8.2929C11.5196 8.10537 11.2652 8.00001 11 8.00001ZM8.17 8.00001C8.3766 7.41448 8.75974 6.90744 9.2666 6.5488C9.77346 6.19015 10.3791 5.99756 11 5.99756C11.6209 5.99756 12.2265 6.19015 12.7334 6.5488C13.2403 6.90744 13.6234 7.41448 13.83 8.00001H15C15.2652 8.00001 15.5196 8.10537 15.7071 8.2929C15.8946 8.48044 16 8.73479 16 9.00001C16 9.26523 15.8946 9.51958 15.7071 9.70712C15.5196 9.89465 15.2652 10 15 10H13.83C13.6234 10.5855 13.2403 11.0926 12.7334 11.4512C12.2265 11.8099 11.6209 12.0025 11 12.0025C10.3791 12.0025 9.77346 11.8099 9.2666 11.4512C8.75974 11.0926 8.3766 10.5855 8.17 10H1C0.734784 10 0.48043 9.89465 0.292893 9.70712C0.105357 9.51958 0 9.26523 0 9.00001C0 8.73479 0.105357 8.48044 0.292893 8.2929C0.48043 8.10537 0.734784 8.00001 1 8.00001H8.17ZM5 14C4.73478 14 4.48043 14.1054 4.29289 14.2929C4.10536 14.4804 4 14.7348 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8947 4.73478 16 5 16C5.26522 16 5.51957 15.8947 5.70711 15.7071C5.89464 15.5196 6 15.2652 6 15C6 14.7348 5.89464 14.4804 5.70711 14.2929C5.51957 14.1054 5.26522 14 5 14ZM2.17 14C2.3766 13.4145 2.75974 12.9074 3.2666 12.5488C3.77346 12.1902 4.37909 11.9976 5 11.9976C5.62091 11.9976 6.22654 12.1902 6.7334 12.5488C7.24026 12.9074 7.6234 13.4145 7.83 14H15C15.2652 14 15.5196 14.1054 15.7071 14.2929C15.8946 14.4804 16 14.7348 16 15C16 15.2652 15.8946 15.5196 15.7071 15.7071C15.5196 15.8947 15.2652 16 15 16H7.83C7.6234 16.5855 7.24026 17.0926 6.7334 17.4512C6.22654 17.8099 5.62091 18.0025 5 18.0025C4.37909 18.0025 3.77346 17.8099 3.2666 17.4512C2.75974 17.0926 2.3766 16.5855 2.17 16H1C0.734784 16 0.48043 15.8947 0.292893 15.7071C0.105357 15.5196 0 15.2652 0 15C0 14.7348 0.105357 14.4804 0.292893 14.2929C0.48043 14.1054 0.734784 14 1 14H2.17Z" fill="#454545" />
                                                </svg>
                                                <span> Bộ lọc</span>
                                            </button>
                                        </label>
                                    </div>
                                    <a type="button" class="btn btn-secondary btn-filter ">
                                        <i class="fa-solid fa-xmark"></i>
                                        <span>Xóa bộ lọc</span>
                                    </a>
                                </div>
                            </div>
                            <!-- ----------------------------------------- -->
                            <div class="row row-cols-1 row-cols-sm-9 row-cols-md-4 index-col-item  ">

                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/1.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/2.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/3.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/4.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/5.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/6.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/7.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/8.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/9.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/10.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/11.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/12.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/13.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/14.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/15.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/16.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/17.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/18.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/19.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/20.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/21.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/22.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-item">
                                    <div class="cold-3 ">
                                        <div class="index-item">
                                            <a href="./detail.php" class="">
                                                <img src="./assets/app/images/content/23.png" alt="" class="index-img" />
                                            </a>
                                            <div class="">
                                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                                <span>License: Demo, Free, Free for Personal Use</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
        
                            </div>
                        </div>
                    </div>
                    <div class="p-2 bd-highlight">
                        <div class="  text-center display-flex">
                            <div class="collection-navigation pt-4 ">
                                <div class=" pt-3">
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination mb-0 justify-content-center index-right-bot ">
                                            <li class="page-item " aria-current="page">
                                                <a class="page-link" href="#">1</a>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item">
                                                <a class="page-link" href="#">3</a>
                                            </li>

                                            <li class="page-item">
                                                <a class="page-link" href="#" aria-label="Next">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                        <g clip-path="url(#clip0_802_450)">
                                                            <path d="M2 9H17M17 9L10.25 2.25M17 9L10.25 15.75" stroke="#454545" stroke-width="2" />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_802_450">
                                                                <rect width="18" height="18" fill="white" transform="translate(0.5)" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                </a>
                                            </li>

                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3 index-left" id="index-left">
                <div class="d-flex flex-column mb-3 index-item-left">
                    <div class="p-2 index-item-left-top">
                        <div class="d-flex justify-content-between ">
                            <div class="d-flex justify-content-start  ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M9 5.00001C8.73478 5.00001 8.48043 5.10537 8.29289 5.2929C8.10536 5.48044 8 5.73479 8 6.00001C8 6.26523 8.10536 6.51958 8.29289 6.70712C8.48043 6.89465 8.73478 7.00001 9 7.00001C9.26522 7.00001 9.51957 6.89465 9.70711 6.70712C9.89464 6.51958 10 6.26523 10 6.00001C10 5.73479 9.89464 5.48044 9.70711 5.2929C9.51957 5.10537 9.26522 5.00001 9 5.00001ZM6.17 5.00001C6.3766 4.41448 6.75974 3.90744 7.2666 3.5488C7.77346 3.19015 8.37909 2.99756 9 2.99756C9.62091 2.99756 10.2265 3.19015 10.7334 3.5488C11.2403 3.90744 11.6234 4.41448 11.83 5.00001H19C19.2652 5.00001 19.5196 5.10537 19.7071 5.2929C19.8946 5.48044 20 5.73479 20 6.00001C20 6.26523 19.8946 6.51958 19.7071 6.70712C19.5196 6.89465 19.2652 7.00001 19 7.00001H11.83C11.6234 7.58554 11.2403 8.09258 10.7334 8.45122C10.2265 8.80986 9.62091 9.00246 9 9.00246C8.37909 9.00246 7.77346 8.80986 7.2666 8.45122C6.75974 8.09258 6.3766 7.58554 6.17 7.00001H5C4.73478 7.00001 4.48043 6.89465 4.29289 6.70712C4.10536 6.51958 4 6.26523 4 6.00001C4 5.73479 4.10536 5.48044 4.29289 5.2929C4.48043 5.10537 4.73478 5.00001 5 5.00001H6.17ZM15 11C14.7348 11 14.4804 11.1054 14.2929 11.2929C14.1054 11.4804 14 11.7348 14 12C14 12.2652 14.1054 12.5196 14.2929 12.7071C14.4804 12.8947 14.7348 13 15 13C15.2652 13 15.5196 12.8947 15.7071 12.7071C15.8946 12.5196 16 12.2652 16 12C16 11.7348 15.8946 11.4804 15.7071 11.2929C15.5196 11.1054 15.2652 11 15 11ZM12.17 11C12.3766 10.4145 12.7597 9.90744 13.2666 9.5488C13.7735 9.19015 14.3791 8.99756 15 8.99756C15.6209 8.99756 16.2265 9.19015 16.7334 9.5488C17.2403 9.90744 17.6234 10.4145 17.83 11H19C19.2652 11 19.5196 11.1054 19.7071 11.2929C19.8946 11.4804 20 11.7348 20 12C20 12.2652 19.8946 12.5196 19.7071 12.7071C19.5196 12.8947 19.2652 13 19 13H17.83C17.6234 13.5855 17.2403 14.0926 16.7334 14.4512C16.2265 14.8099 15.6209 15.0025 15 15.0025C14.3791 15.0025 13.7735 14.8099 13.2666 14.4512C12.7597 14.0926 12.3766 13.5855 12.17 13H5C4.73478 13 4.48043 12.8947 4.29289 12.7071C4.10536 12.5196 4 12.2652 4 12C4 11.7348 4.10536 11.4804 4.29289 11.2929C4.48043 11.1054 4.73478 11 5 11H12.17ZM9 17C8.73478 17 8.48043 17.1054 8.29289 17.2929C8.10536 17.4804 8 17.7348 8 18C8 18.2652 8.10536 18.5196 8.29289 18.7071C8.48043 18.8947 8.73478 19 9 19C9.26522 19 9.51957 18.8947 9.70711 18.7071C9.89464 18.5196 10 18.2652 10 18C10 17.7348 9.89464 17.4804 9.70711 17.2929C9.51957 17.1054 9.26522 17 9 17ZM6.17 17C6.3766 16.4145 6.75974 15.9074 7.2666 15.5488C7.77346 15.1902 8.37909 14.9976 9 14.9976C9.62091 14.9976 10.2265 15.1902 10.7334 15.5488C11.2403 15.9074 11.6234 16.4145 11.83 17H19C19.2652 17 19.5196 17.1054 19.7071 17.2929C19.8946 17.4804 20 17.7348 20 18C20 18.2652 19.8946 18.5196 19.7071 18.7071C19.5196 18.8947 19.2652 19 19 19H11.83C11.6234 19.5855 11.2403 20.0926 10.7334 20.4512C10.2265 20.8099 9.62091 21.0025 9 21.0025C8.37909 21.0025 7.77346 20.8099 7.2666 20.4512C6.75974 20.0926 6.3766 19.5855 6.17 19H5C4.73478 19 4.48043 18.8947 4.29289 18.7071C4.10536 18.5196 4 18.2652 4 18C4 17.7348 4.10536 17.4804 4.29289 17.2929C4.48043 17.1054 4.73478 17 5 17H6.17Z" fill="#454545" />
                                </svg>
                                <h5>Filters</h5>

                            </div>
                            <div class="d-flex justify-content-end filters-div-close">
                                <button class=" sidebar-close">
                                <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                            <div class="d-flex justify-content-end clear-all">
                                <p>Clear all</p>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                    <rect width="14" height="14" fill="white" />
                                    <path d="M4.08331 4.0835L9.91665 9.91683M4.08331 9.91683L9.91665 4.0835" stroke="#454545" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            
                        </div>
                        <div class="p-2 index-item-active">
                            <div class="d-flex flex-wrap ">

                                <a class="btn-group btn-secondary btn-group-toggle top-btn active" role="button" data-bs-toggle="button" aria-pressed="true" href="">
                                    Free
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                        <path d="M4.08337 4.58337L9.91671 10.4167M4.08337 10.4167L9.91671 4.58337" stroke="#F8F8F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn active" role="button" data-bs-toggle="button" aria-pressed="true" href="">Not free for commercial use
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15" fill="none">
                                        <path d="M4.08331 4.58337L9.91665 10.4167M4.08331 10.4167L9.91665 4.58337" stroke="#F8F8F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>




                            </div>
                        </div>

                    </div>
                    <div class="p-2">

                        <div class="d-flex justify-content-start">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M12 6L16 12L21 8L19 18H5L3 8L8 12L12 6Z" stroke="#454545" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <h5>License</h5>
                        </div>
                        <div class="p-2 ">
                            <div class="d-flex flex-wrap license-div">
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn active" href="">Not free for commercial use</a>
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Demo</a>
                                <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Free for Personal Use</a>


                            </div>
                        </div>

                    </div>
                    <div class="p-2">
                        <div class="d-flex flex-column mb-3">
                            <div class="d-flex justify-content-start">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <g clip-path="url(#clip0_802_32)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.586 2.75696C15.9611 2.38202 16.4697 2.17139 17 2.17139C17.5303 2.17139 18.0389 2.38202 18.414 2.75696L21.243 5.58596C21.6179 5.96101 21.8286 6.46963 21.8286 6.99996C21.8286 7.53029 21.6179 8.0389 21.243 8.41396L18.414 11.243C18.0389 11.6179 17.5303 11.8285 17 11.8285C16.4697 11.8285 15.9611 11.6179 15.586 11.243L12.757 8.41396C12.3821 8.0389 12.1714 7.53029 12.1714 6.99996C12.1714 6.46963 12.3821 5.96101 12.757 5.58596L15.586 2.75696ZM17 4.17196L14.172 6.99996L17 9.82796L19.828 6.99996L17 4.17196ZM9 2.99996C9.53043 2.99996 10.0391 3.21067 10.4142 3.58575C10.7893 3.96082 11 4.46953 11 4.99996V8.99996C11 9.53039 10.7893 10.0391 10.4142 10.4142C10.0391 10.7892 9.53043 11 9 11H5C4.46957 11 3.96086 10.7892 3.58579 10.4142C3.21071 10.0391 3 9.53039 3 8.99996V4.99996C3 4.46953 3.21071 3.96082 3.58579 3.58575C3.96086 3.21067 4.46957 2.99996 5 2.99996H9ZM9 4.99996H5V8.99996H9V4.99996ZM21 15C21 14.4695 20.7893 13.9608 20.4142 13.5857C20.0391 13.2107 19.5304 13 19 13H15C14.4696 13 13.9609 13.2107 13.5858 13.5857C13.2107 13.9608 13 14.4695 13 15V19C13 19.5304 13.2107 20.0391 13.5858 20.4142C13.9609 20.7892 14.4696 21 15 21H19C19.5304 21 20.0391 20.7892 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V15ZM19 15V19H15V15H19ZM9 13C9.53043 13 10.0391 13.2107 10.4142 13.5857C10.7893 13.9608 11 14.4695 11 15V19C11 19.5304 10.7893 20.0391 10.4142 20.4142C10.0391 20.7892 9.53043 21 9 21H5C4.46957 21 3.96086 20.7892 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15C3 14.4695 3.21071 13.9608 3.58579 13.5857C3.96086 13.2107 4.46957 13 5 13H9ZM9 15H5V19H9V15Z" fill="#454545" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_802_32">
                                            <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                                <h5>Browse Font</h5>
                            </div>
                            <div class="p-2">
                                <div class="d-flex flex-wrap browse-div">
                                    <a class="btn-group btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Serif (1)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Sans Serif (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Script (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Vintage - Retro (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Noel (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Comic (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Valentine (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Calligraphy (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Brush (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Halloween (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Display (23)</a>
                                    <a class="btn-group  btn-secondary btn-group-toggle top-btn" href="">Other (23)</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>








</section>

<?php include 'template/footer.php' ?>