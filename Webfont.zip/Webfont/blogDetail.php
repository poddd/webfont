<?php include 'template/header.php' ?>

<section class=" container-fluid">
    <div class="blog">
        <div class="row blog-row">
            <div class="col blog-topp top-detail">
                <div class="d-flex flex-column bd-highlight mb-3">
                    <div class="p-9 bd-highlight blog-top blog-top-left">
                        <div class="">
                            <div class="p-2 blog-top-link">
                                <div class="">
                                    <a href="">Home</a>

                                    <i class="fa-solid fa-chevron-right"></i>

                                    <a href=" " class=" a-blog " act>Bog</a>
                                    <i class="fa-solid fa-chevron-right"></i>

                                    <a href=" " class=" a-blog " act> Instructions for installing fonts</a>
                                </div>
                            </div>
                            <div class="p-2">
                                <div class="col  ">

                                    <h3> Instructions for installing fonts</h3>
                                    <div class="d-flex blog-detail-link ">
                                        <div class=" blog-p2 flex-fill">Admin</div>
                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                            <a href="">Instruct</a>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-column mb-3 blog-detail-mid">
                                        <div class="p-2">
                                            <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                        </div>
                                        <div class="p-2"><span>Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! Masterfully designed to become a true favorite, this font has the potential to bring each of your creative ideas to the highest level! This font is PUA encoded which means you can access all of the glyphs and swashes with ease!</span></div>
                                        <div class="p-2"><span>Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! Masterfully designed to become a true favorite, this font has the potential to bring each of your creative ideas to the highest level! This font is PUA encoded which means you can access all of the glyphs and swashes with ease!</span></div>
                                        <div class="p-2"><span>Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! Masterfully designed to become a true favorite, this font has the potential to bring each of your creative ideas to the highest level! This font is PUA encoded which means you can access all of the glyphs and swashes with ease!</span></div>
                                        <hr>
                                    </div>





                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="  blog-top ">
                        <div class="p-2">
                            <div class="col ">
                                <h3 class="h3-blogdetail">Other articles</h3>
                                <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                    <!-- <div class="p-2"> -->
                                    <div class="row blog-bot-link-item">
                                        <div class="col-sm-4">
                                            <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                        </div>
                                        <div class="col-sm-8 row blog-bot-link-detail">
                                            <div class="d-flex flex-column mb-3">
                                                <div class=" blog-p2">
                                                    <h4>Instructions for installing fonts</h4>
                                                    <div class="d-flex blog-bot-link-detail-author">
                                                        <div class=" blog-p2 flex-fill">Admin</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                            <a href="">Instruct</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- </div> -->

                                </div>
                                <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                    <!-- <div class="p-2"> -->
                                    <div class="row blog-bot-link-item">
                                        <div class="col-sm-4">
                                            <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                        </div>
                                        <div class="col-sm-8 row blog-bot-link-detail">
                                            <div class="d-flex flex-column mb-3">
                                                <div class=" blog-p2">
                                                    <h4>Instructions for installing fonts</h4>
                                                    <div class="d-flex blog-bot-link-detail-author">
                                                        <div class=" blog-p2 flex-fill">Admin</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                            <a href="">Instruct</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- </div> -->

                                </div>
                                <div class=" text-center d-flex flex-column-reverse text-left blog-bot-link">
                                    <!-- <div class="p-2"> -->
                                    <div class="row blog-bot-link-item">
                                        <div class="col-sm-4">
                                            <img src="./assets/app/images/content/Frame 34.png" alt="" class="" />
                                        </div>
                                        <div class="col-sm-8 row blog-bot-link-detail">
                                            <div class="d-flex flex-column mb-3">
                                                <div class=" blog-p2">
                                                    <h4>Instructions for installing fonts</h4>
                                                    <div class="d-flex blog-bot-link-detail-author">
                                                        <div class=" blog-p2 flex-fill">Admin</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-date"> 22/12/2022</div>
                                                        <div class=" blog-p2 flex-fill blog-bot-link-detail-author-cate">Categories:
                                                            <a href="">Instruct</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="blog-p2 blog-bot-link-detail-p">Bunlay Font feels playfully nostalgic and delivers an incredible vintage aesthetic. Use this serif font to add that special retro touch to any design idea you can think of! ...2</div>
                                                <div class="blog-p2 blog-bot-link-detail-a"><a href="">See more</a></div>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- </div> -->

                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-5  blog-right blog-detail-right">
                <h3>Font Random</h3>
                <!-- <div class="container "> -->
                <div class="row container  row-cols-md-2 .col-md-3  text-left  blog-right-item-detail">
                    <div class="col-lg-4 col-md-3 col-sm-12  blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/Frame 34.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/1.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/2.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/3.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/4.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/5.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/6.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-12 blog-col ">
                        <div class="blog-right-item">
                            <a href="./detail.php" class="">
                                <img src="./assets/app/images/content/7.png" alt="" class="index-img" />
                            </a>
                            <div class="">
                                <h4 class="text-left ">Bunlay Font - Free download</h4>
                                <span>License: Demo, Free, Free for Personal Use</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- </div> -->
            </div>
        </div>
    </div>

</section>

<?php include 'template/footer.php' ?>