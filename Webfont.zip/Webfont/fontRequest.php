<?php include 'template/header.php' ?>
<section class="container-fluid">
    <div class="request-page">
        <div class="p-2 ">
            <div class="blog-top-link">
                <a href="">Home</a>
                <i class="fa-solid fa-chevron-right"></i>
                <a href=" " class=" a-blog " act>Font Request</a>

            </div>
        </div>

        <dib class="col">
            <div class="font-request-form">
                <h3>Font Request</h3>
                <form action="">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Name *</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter your name">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Email your name">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">The country you live in *</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="The country you live in">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Request the font you want to update on the website *</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="" cols="">Type your request here</textarea>
                    </div>
                    <button type="button" class="btn btn-primary send" data-bs-toggle="modal" data-bs-target="#requestPopup">
                        <span class="btn-span">Send</span>
                    </button>
                </form>
                <!-- Modal -->
                <div class="modal fade" id="requestPopup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="btn-model">

                                <button type="button" class="btn-close" data-bs-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                        <path d="M16 2C8.2 2 2 8.2 2 16C2 23.8 8.2 30 16 30C23.8 30 30 23.8 30 16C30 8.2 23.8 2 16 2ZM21.4 23L16 17.6L10.6 23L9 21.4L14.4 16L9 10.6L10.6 9L16 14.4L21.4 9L23 10.6L17.6 16L23 21.4L21.4 23Z" fill="#454545" />
                                    </svg>
                                </button>
                            </div>
                            <div class="modal-body text-center ">
                                <!-- <button type="button" class="btn-close" data-bs-dismiss="modal"></button> -->
                                <h3>You have successfully submitted</h3>
                                <span>We will search for this font. If there is, we will update it on the website.

                                    Thank you for visiting fontlovez.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </dib>

    </div>

    <!-- <hr> -->
</section>
<?php include 'template/footer.php' ?>